#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/pip install --index-url https://download.pytorch.org/whl/cpu 'torch==2.6.0'
.venv/bin/pip install transformers==4.51.3 peft==0.15.2 accelerate==1.6.0 safetensors==0.5.3 psutil==7.0.0
HF_HUB_DISABLE_XET=1 .venv/bin/python download_model.py
export OMP_NUM_THREADS=6 MKL_NUM_THREADS=6 TOKENIZERS_PARALLELISM=false HF_HUB_OFFLINE=1
.venv/bin/python -u train.py --steps "${1:-48}" | tee train.log
.venv/bin/python -u evaluate_reload.py | tee reload.log
.venv/bin/python export_artifact.py
