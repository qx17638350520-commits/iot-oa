"""Read-only text generation with the independently loadable trained adapter."""
import argparse,json
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from peft import PeftModel
from train import P,load_rows
p=argparse.ArgumentParser();p.add_argument('prompt');p.add_argument('--max-new-tokens',type=int,default=160);p.add_argument('--base-only',action='store_true');a=p.parse_args()
if not 1<=a.max_new_tokens<=512:p.error('max-new-tokens must be 1..512')
torch.set_num_threads(6);tok=AutoTokenizer.from_pretrained(P/'base_model',local_files_only=True,trust_remote_code=False)
model=AutoModelForCausalLM.from_pretrained(P/'base_model',torch_dtype=torch.float32,local_files_only=True,trust_remote_code=False,attn_implementation='sdpa')
if not a.base_only:model=PeftModel.from_pretrained(model,P/'adapter',is_trainable=False,local_files_only=True)
model.eval();messages=[load_rows('train')[0]['messages'][0],{'role':'user','content':a.prompt}]
ids=tok.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_tensors='pt')
if ids.shape[1]>1024:p.error('Input exceeds 1024 tokens')
with torch.inference_mode():out=model.generate(ids,attention_mask=torch.ones_like(ids),max_new_tokens=a.max_new_tokens,do_sample=False,use_cache=True,temperature=None,top_p=None,top_k=None,pad_token_id=tok.eos_token_id)
print(json.dumps({'model':'base' if a.base_only else 'base + trained IoT LoRA adapter','response':tok.decode(out[0,ids.shape[1]:],skip_special_tokens=True),'generated_tokens':out.shape[1]-ids.shape[1],'hit_token_limit':out.shape[1]-ids.shape[1]>=a.max_new_tokens,'warning':'Synthetic training demonstration. Verify all advice; no physical device control.'},ensure_ascii=False,indent=2))
