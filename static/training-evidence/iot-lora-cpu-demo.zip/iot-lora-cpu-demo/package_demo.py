from pathlib import Path
import hashlib,zipfile
P=Path(__file__).resolve().parent
names=['README.md','LICENSE','BASE_MODEL_LICENSE','BASE_MODEL_README.md','requirements.txt','requirements-lock.txt','model_revision.txt','artifact.schema.json','run_cpu.sh','create_dataset.py','download_model.py','train.py','evaluate_reload.py','infer.py','export_artifact.py','verify_artifacts.py','package_demo.py','train.log','reload.log','inference_cli_stderr.log']
files=[P/n for n in names]+[p for d in ['data','adapter','results'] for p in (P/d).rglob('*') if p.is_file()]
assert all(p.exists() for p in files)
manifest=P/'MANIFEST.sha256';manifest.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(P)}\n' for p in sorted(files)))
files.append(manifest)
z=P/'iot-lora-cpu-demo.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for p in files:out.write(p,Path('iot-lora-cpu-demo')/p.relative_to(P))
with zipfile.ZipFile(z) as out:
 assert out.testzip() is None
 for line in out.read('iot-lora-cpu-demo/MANIFEST.sha256').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(out.read('iot-lora-cpu-demo/'+n)).hexdigest()==h,n
print(z, z.stat().st_size, 'bytes', len(files), 'files', hashlib.sha256(z.read_bytes()).hexdigest())
