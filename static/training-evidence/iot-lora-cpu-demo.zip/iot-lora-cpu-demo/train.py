"""Real CPU LoRA supervised fine-tuning. All metrics are computed, never simulated."""
import argparse,hashlib,json,os,platform,random,resource,time
from pathlib import Path
import torch,psutil,transformers,peft
from transformers import AutoTokenizer,AutoModelForCausalLM
from peft import LoraConfig,get_peft_model
P=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_rows(split):return [json.loads(s) for s in (P/'data'/f'{split}.jsonl').read_text().splitlines()]
def encode(tok,row):
 prompt=tok.apply_chat_template(row['messages'][:-1],tokenize=True,add_generation_prompt=True)
 ids=tok.apply_chat_template(row['messages'],tokenize=True,add_generation_prompt=False)
 if len(ids)>384:raise ValueError(f"Sequence too long: {row['id']} {len(ids)}")
 labels=[-100]*len(prompt)+ids[len(prompt):]
 return {'input_ids':torch.tensor([ids]),'attention_mask':torch.ones(1,len(ids),dtype=torch.long),'labels':torch.tensor([labels])}
def evaluate(model,rows):
 model.eval();total=0.;count=0;items=[]
 with torch.inference_mode():
  for row,b in rows:
   loss=float(model(**b).loss);n=int((b['labels'][:,1:]!=-100).sum());total+=loss*n;count+=n
   items.append({'id':row['id'],'loss':loss,'target_tokens':n})
 return {'answer_token_weighted_loss':total/count,'target_tokens':count,'examples':items}
def generate(model,tok,rows):
 model.eval();items=[]
 with torch.inference_mode():
  for row in rows[:3]:
   inputs=tok.apply_chat_template(row['messages'][:-1],tokenize=True,add_generation_prompt=True,return_tensors='pt')
   t=time.perf_counter();out=model.generate(inputs,attention_mask=torch.ones_like(inputs),max_new_tokens=128,do_sample=False,use_cache=True,temperature=None,top_p=None,top_k=None,pad_token_id=tok.eos_token_id)
   items.append({'id':row['id'],'prompt':row['messages'][-2]['content'],'response':tok.decode(out[0,inputs.shape[1]:],skip_special_tokens=True),'elapsed_seconds':time.perf_counter()-t,'generated_tokens':out.shape[1]-inputs.shape[1],'hit_token_limit':out.shape[1]-inputs.shape[1]>=128})
 return items

def main():
 a=argparse.ArgumentParser();a.add_argument('--steps',type=int,default=48);a.add_argument('--threads',type=int,default=6);args=a.parse_args()
 os.chdir(P);torch.set_num_threads(args.threads);torch.manual_seed(42);random.seed(42)
 out=P/'results';out.mkdir(exist_ok=True);start=time.perf_counter()
 tok=AutoTokenizer.from_pretrained(P/'base_model',local_files_only=True,trust_remote_code=False)
 model=AutoModelForCausalLM.from_pretrained(P/'base_model',torch_dtype=torch.float32,local_files_only=True,trust_remote_code=False,attn_implementation='sdpa')
 model.config.use_cache=False
 raw_train,raw_eval=load_rows('train'),load_rows('heldout')
 train=[(r,encode(tok,r)) for r in raw_train];held=[(r,encode(tok,r)) for r in raw_eval]
 base={'evaluation':evaluate(model,held),'generations':generate(model,tok,raw_eval)}
 (out/'baseline.json').write_text(json.dumps(base,ensure_ascii=False,indent=2));print('BASELINE',base['evaluation']['answer_token_weighted_loss'],flush=True)
 cfg=LoraConfig(r=8,lora_alpha=16,lora_dropout=0.05,target_modules=['q_proj','v_proj'],bias='none',task_type='CAUSAL_LM')
 model=get_peft_model(model,cfg);trainable=sum(p.numel() for p in model.parameters() if p.requires_grad);total=sum(p.numel() for p in model.parameters())
 optim=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=0.0002,weight_decay=0.01)
 indices=list(range(len(train)));random.shuffle(indices);logs=[];train_start=time.perf_counter()
 with (out/'steps.jsonl').open('w') as f:
  for step in range(args.steps):
   if step and step%len(train)==0:random.shuffle(indices)
   row,b=train[indices[step%len(train)]];model.train();ts=time.perf_counter();optim.zero_grad(set_to_none=True)
   loss=model(**b).loss
   if not torch.isfinite(loss):raise RuntimeError('Nonfinite loss')
   loss.backward();grad=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.0));optim.step()
   item={'step':step+1,'example_id':row['id'],'loss':float(loss.detach()),'grad_norm':grad,'elapsed_seconds':time.perf_counter()-ts,'rss_mb':psutil.Process().memory_info().rss/1024**2}
   logs.append(item);f.write(json.dumps(item)+'\n');f.flush();print(json.dumps(item),flush=True)
   if step==4:
    avg=sum(x['elapsed_seconds'] for x in logs)/5
    print('BENCHMARK_5_STEPS_SECONDS',avg,flush=True)
    if avg>60:raise RuntimeError('CPU budget guard: >60 seconds per step')
   if time.perf_counter()-train_start>900:raise RuntimeError('CPU budget guard: training exceeded 15 minutes')
 adapter=P/'adapter';model.save_pretrained(adapter,safe_serialization=True);tok.save_pretrained(adapter)
 result={'schema_version':'iot-lora-training/v1','status':'trained_pending_independent_reload','run_id':'qwen-iot-lora-cpu-20261010','model':{'id':'Qwen/Qwen2.5-0.5B-Instruct','revision':(P/'model_revision.txt').read_text().strip(),'license':'Apache-2.0','dtype':'float32','trust_remote_code':False},'method':{'type':'LoRA','rank':8,'alpha':16,'dropout':0.05,'target_modules':['q_proj','v_proj'],'trainable_parameters':trainable,'total_parameters_including_adapter':total,'optimizer':'AdamW','learning_rate':0.0002,'weight_decay':0.01,'batch_size':1,'seed':42,'steps':len(logs),'max_sequence_tokens':384,'actual_max_sequence_tokens':max(b['input_ids'].shape[1] for _,b in train+held),'assistant_only_loss':True},'dataset':{'provenance':'Original synthetic Chinese instructional Q&A; no real customer or device data','train_examples':len(train),'heldout_examples':len(held),'split':'Manually distinct scenarios; heldout never used in optimization or checkpoint selection','sha256':{s:sha(P/'data'/f'{s}.jsonl') for s in ['train','heldout']}},'runtime':{'device':'cpu','threads':args.threads,'python':platform.python_version(),'torch':torch.__version__,'transformers':transformers.__version__,'peft':peft.__version__,'training_seconds':time.perf_counter()-train_start,'total_seconds':time.perf_counter()-start,'peak_rss_mb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024},'training_log':logs,'baseline':base,'adapter_files':{str(p.relative_to(P)):sha(p) for p in adapter.iterdir() if p.is_file()},'limitations':['Small synthetic proof of real optimization, not a production or procurement acceptance benchmark.','Six held-out examples and three greedy generations cannot establish general capability.','No physical device control; no guarantee of factual correctness.','Static hosted UI displays this completed run; training requires Python execution.']}
 (out/'training_run.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('TRAINING_SAVED',flush=True)
if __name__=='__main__':main()
