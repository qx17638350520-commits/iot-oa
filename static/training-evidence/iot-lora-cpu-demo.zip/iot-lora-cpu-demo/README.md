# 中文物联网 LoRA 真实训练演示

This package contains a real, small supervised fine-tuning experiment on Qwen/Qwen2.5-0.5B-Instruct using CPU PyTorch and PEFT LoRA. It is a reproducible educational demonstration, not proof of industrial deployment readiness or tender acceptance.

## What is real

- Original Chinese instructional dataset: 24 training examples and 6 distinct held-out scenarios.
- An actual pretrained causal language model, not a keyword classifier or simulated loss chart.
- Actual backward passes, AdamW optimizer updates, saved LoRA tensors, and measured per-step logs.
- Before/after answer-token-weighted negative log likelihood on the same held-out set.
- Three deterministic before/after text generations. Truncation is explicitly recorded.
- A separate Python process reloads the saved adapter and verifies its file hashes before reporting completed results.

No private customer data, real device telemetry, paid API, API key, GPU, or connection to physical equipment is used. The data is original synthetic educational prose, not an externally validated industrial corpus. Held-out samples are manually separated scenarios within the same small subject area, not a representative production test set. Loss improvement must not be presented as accuracy, safety certification, or compliance.

## Reproduce

Tested on Python 3.12 with Linux CPU. Allow approximately 5 GB free RAM and 4 GB free disk (additional headroom recommended). The original run uses 6 CPU threads. Initial setup downloads official PyTorch/PyPI packages and approximately 1 GB of model weights from Hugging Face. No remote model code is enabled; model weights are safetensors.

1. Inspect the scripts and dataset.
2. Run `bash run_cpu.sh 48` from this directory. This creates an isolated `.venv`, installs pinned direct dependencies, downloads the pinned official model revision, executes 48 actual optimization steps, and runs evaluation in a fresh process.
3. Read `results/completed_run.json`, `results/steps.jsonl`, and `results/ui_training_record.json`.
4. Run `.venv/bin/python infer.py 'MQTT连接成功但没有新数据，如何只读排查？'` for a new read-only inference. Add `--base-only` for the original model.

The adapter is included, so to run inference only: install the dependencies as shown in `run_cpu.sh`, run `download_model.py`, then run `infer.py`. Do not run `train.py` if you want to preserve the supplied adapter and results. Rerunning training overwrites the demonstration output directory. Numerical results may differ with hardware/library versions. `requirements-lock.txt` records the environment used for the supplied run; `requirements.txt` lists direct dependencies. CPU torch uses the official CPU index rather than the default PyPI CUDA package.

## Method

- Base model: Qwen/Qwen2.5-0.5B-Instruct, pinned commit in `model_revision.txt`.
- Float32 CPU, PEFT LoRA rank 8 / alpha 16 / dropout 0.05 on attention q_proj and v_proj.
- Only adapter weights are optimized. AdamW, learning rate 0.0002, weight decay 0.01, batch size 1, gradient clipping 1.0, seed 42.
- Assistant-answer-only loss; system and user prompt tokens are masked with -100.
- No silent sequence truncation; samples above 384 tokens fail explicitly.
- Training order is shuffled deterministically each epoch. 48 steps is two passes over 24 examples.
- The five-step benchmark is the first five genuine updates within that same run, not a separately chosen checkpoint. It guards against steps exceeding 60 seconds. Training also has a 15-minute safety limit. Only the final fixed-step adapter is evaluated after training; no held-out checkpoint selection.
- Evaluation weights each example's cross entropy by the number of supervised answer tokens. Lower is better on this narrowly defined set. Generation uses greedy decoding with 128 new-token cap, consistent before and after.

## Static application integration

Import `results/ui_training_record.json` as a completed, auditable record and validate it against `artifact.schema.json`. Render `training_curve` using its stored, measured points. Label the card “已完成的真实 CPU 训练记录” and show model revision, training/held-out counts, optimization steps, loss before/after, timing, peak RSS, reload verification, synthetic data provenance, and limitations.

Do not animate this record as a currently running job or relabel “load results” as “start training.” A static Sites page cannot execute this Python CPU workflow. Use separate actions: “查看已完成训练”, “下载训练包”, and “导入本地训练结果”. A user may run the downloadable Python runner in an appropriate compute environment and import its newly generated artifact. A future live backend would need a genuine authenticated job API, persistent job lifecycle, resource controls, and its own independent validation before a hosted “train” button could claim to start work.

Render imported strings as text, not HTML. Treat metrics as untrusted imported data, preserve the difference between locally supplied results and independently verified bundled results, and never grant imported data control of real devices.

## Files

- `data/train.jsonl`, `data/heldout.jsonl`: original dataset with explicit provenance.
- `adapter/adapter_model.safetensors`: actual trained low-rank weights; `adapter_config.json` describes architecture. Base weights are downloaded separately to avoid a large bundle.
- `train.py`, `evaluate_reload.py`, `infer.py`, `download_model.py`, `run_cpu.sh`: executable workflow.
- `results/completed_run.json`: full training, baseline, reload, and evaluation evidence.
- `results/ui_training_record.json`: compact portable application record.
- `results/steps.jsonl`: actual optimizer-step log.
- `artifact.schema.json`: UI record JSON Schema.
- `MANIFEST.sha256`: checksums of packaged artifacts.

## Sources and license

- Official base model and model card: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct
- PEFT quicktour: https://huggingface.co/docs/peft/v0.15.0/en/quicktour
- Transformers chat templates: https://huggingface.co/docs/transformers/v4.51.3/en/chat_templating
- PyTorch CPU installation: https://pytorch.org/get-started/locally/

The base model is Apache-2.0; its upstream license is included as `BASE_MODEL_LICENSE`. Preserve upstream attribution and license when redistributing the base or derived adapter. Original scripts and synthetic dataset in this demonstration are supplied for educational use under Apache-2.0, with no warranty. The original model card is included as `BASE_MODEL_README.md`. Training modifies only the adapter; the base weights themselves are unchanged.

## Measured result and limitations of this supplied run

The supplied run completed 48 updates in 48.74 seconds (6 CPU threads), training 540,672 adapter parameters. Training-process peak RSS was 3214.32 MiB (about 3.14 GiB); the full training script, including baseline evaluation/generation, took 110.27 seconds. Independent reload/evaluation took another 23.41 seconds.

Held-out answer-token loss went from 4.13369 to 3.37735, a descriptive reduction of 18.30%. This is not accuracy. Manual inspection of the three paired generations found continued mistakes and a regression: the base duplicate-event answer mentioned unique identifiers, while the fine-tuned answer omitted useful deduplication guidance. The timestamp answer did not explain retained messages. The sensor answer was less numerically fabricated than the baseline but still introduced unsupported diagnostic language. These are preserved in the full results and UI artifact; no best-case-only selection was used. The useful conclusion is that genuine training, artifact export, reload and inference work end to end, while this small run does not establish reliable domain capability.

`verification.json` records consistency checks. All 48 LoRA B matrices were nonzero after training (they begin at zero in this PEFT initialization), all logged gradients/losses were finite, all 30 prompt/answer masking boundaries matched, data prompts were disjoint, and adapter/data checksums matched. The 6 held-out scenarios all had lower answer-token loss, but that did not prevent worse free-text answers.
