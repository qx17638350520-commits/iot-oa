"""Fresh process independently loads saved adapter and evaluates unseen scenarios."""
import json,time,resource
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from peft import PeftModel
from train import P,load_rows,encode,evaluate,generate,sha

def main():
 torch.set_num_threads(6);torch.manual_seed(42);start=time.perf_counter()
 result=json.loads((P/'results/training_run.json').read_text());tok=AutoTokenizer.from_pretrained(P/'base_model',local_files_only=True,trust_remote_code=False)
 base=AutoModelForCausalLM.from_pretrained(P/'base_model',local_files_only=True,trust_remote_code=False,torch_dtype=torch.float32,attn_implementation='sdpa')
 model=PeftModel.from_pretrained(base,P/'adapter',is_trainable=False,local_files_only=True);raw=load_rows('heldout');held=[(r,encode(tok,r)) for r in raw]
 evaluated=evaluate(model,held);generations=generate(model,tok,raw)
 before=result['baseline']['evaluation']['answer_token_weighted_loss'];after=evaluated['answer_token_weighted_loss']
 result['after_reload']={'evaluation':evaluated,'generations':generations,'fresh_process':True,'seconds':time.perf_counter()-start,'peak_rss_mb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'adapter_hash_verified':all(sha(P/p)==h for p,h in result['adapter_files'].items())}
 result['comparison']={'heldout_loss_before':before,'heldout_loss_after':after,'heldout_loss_delta':after-before,'relative_loss_reduction_percent':100*(before-after)/before,'interpretation':'Descriptive loss on six synthetic held-out examples only; not accuracy or industrial capability.'};result['status']='completed'
 (P/'results/completed_run.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result['comparison'],indent=2));print('FRESH_PROCESS_RELOAD_VERIFIED',result['after_reload']['adapter_hash_verified'])
if __name__=='__main__':main()
