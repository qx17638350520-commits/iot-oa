"""Check run consistency, adapter tensors, data isolation and answer masking."""
import json,math
import torch
from safetensors.torch import load_file
from transformers import AutoTokenizer
from train import P,sha,load_rows
r=json.loads((P/'results/completed_run.json').read_text())
assert r['status']=='completed' and r['after_reload']['fresh_process'] and r['after_reload']['adapter_hash_verified']
assert len(r['training_log'])==r['method']['steps']==48
assert [x['step'] for x in r['training_log']]==list(range(1,49))
assert all(math.isfinite(x['loss']) and x['grad_norm']>0 for x in r['training_log'])
for path,h in r['adapter_files'].items():assert sha(P/path)==h,path
for split,h in r['dataset']['sha256'].items():assert sha(P/'data'/f'{split}.jsonl')==h
train,held=load_rows('train'),load_rows('heldout');assert len(train)==24 and len(held)==6
assert not {r['messages'][-2]['content'] for r in train}&{r['messages'][-2]['content'] for r in held}
tok=AutoTokenizer.from_pretrained(P/'base_model',local_files_only=True)
for row in train+held:
 prompt=tok.apply_chat_template(row['messages'][:-1],tokenize=True,add_generation_prompt=True);full=tok.apply_chat_template(row['messages'],tokenize=True)
 assert full[:len(prompt)]==prompt
w=load_file(P/'adapter/adapter_model.safetensors');assert w
b={k:v for k,v in w.items() if 'lora_B' in k};assert b and all(torch.isfinite(v).all() and torch.count_nonzero(v)>0 for v in b.values())
assert sum(v.numel() for v in w.values())==r['method']['trainable_parameters']
for section in [r['baseline'],r['after_reload']]:
 ev=section['evaluation'];assert abs(sum(x['loss']*x['target_tokens'] for x in ev['examples'])/ev['target_tokens']-ev['answer_token_weighted_loss'])<1e-9
print(json.dumps({'status':'passed','checks':['48 actual logged optimizer updates','finite gradients/loss','adapter and dataset SHA-256','disjoint prompts','30 valid assistant-only masking boundaries','all LoRA B tensors changed from zero initialization','trainable parameter count','weighted evaluation arithmetic','fresh-process reload'], 'adapter_tensors':len(w),'nonzero_lora_B_tensors':len(b),'adapter_parameters':sum(v.numel() for v in w.values())},indent=2))
