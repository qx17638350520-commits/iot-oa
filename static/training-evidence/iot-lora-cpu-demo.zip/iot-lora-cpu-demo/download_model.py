from huggingface_hub import snapshot_download
from pathlib import Path
snapshot_download('Qwen/Qwen2.5-0.5B-Instruct',revision=Path('model_revision.txt').read_text().strip(),local_dir='base_model',allow_patterns=['*.json','*.safetensors','*.txt','*.md','LICENSE','*.jinja'],max_workers=2)
