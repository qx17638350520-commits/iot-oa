"""Produce a compact completed-run artifact; never fabricate a live training state."""
import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
r=json.loads((P/'results/completed_run.json').read_text())
assert r['status']=='completed' and r['after_reload']['fresh_process'] and r['after_reload']['adapter_hash_verified']
a={'schema_version':'iot-lora-ui/v1','kind':'completed_training_record','status':'completed','run_id':r['run_id'],'title':'中文物联网 Qwen LoRA 真实训练记录','execution':'offline_cpu_python','is_live_job':False,'model':r['model'],'method':r['method'],'dataset':r['dataset'],'runtime':r['runtime'],'metrics':r['comparison'],'training_curve':[{'step':x['step'],'loss':x['loss'],'seconds':x['elapsed_seconds'],'rss_mb':x['rss_mb']} for x in r['training_log']],'reload_verified':True,'generation_comparisons':[{'id':b['id'],'prompt':b['prompt'],'before':b['response'],'after':c['response'],'before_truncated':b['hit_token_limit'],'after_truncated':c['hit_token_limit']} for b,c in zip(r['baseline']['generations'],r['after_reload']['generations'])],'limitations':r['limitations'],'manual_generation_review':r.get('manual_generation_review',{}),'artifact_sha256':r['adapter_files']}
(P/'results/ui_training_record.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
print('Exported completed record with',len(a['training_curve']),'real optimization steps')
